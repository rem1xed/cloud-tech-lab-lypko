import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')

def handler(event, context):
    table_name = os.environ.get('TABLE_NAME', 'lp-dev-lab1-courses')
    table = dynamodb.Table(table_name)
    response = table.scan()
    
    return {
        'statusCode': 200,
        'body': json.dumps(response.get('Items', []))
    }
import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')

def handler(event, context):
    table_name = os.environ.get('TABLE_NAME', 'lp-dev-lab1-courses')
    table = dynamodb.Table(table_name)
    
    body = json.loads(event.get('body', '{}'))
    table.put_item(Item=body)
    
    return {
        'statusCode': 201,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(body)
    }
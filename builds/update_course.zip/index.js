const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({ region: "eu-central-1" });
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
    const data = event.body ? JSON.parse(event.body) : event;
    const courseId = event.pathParameters ? event.pathParameters.id : data.id;

    const item = {
        id: courseId,
        title: data.title,
        watchHref: data.watchHref,
        authorId: data.authorId,
        length: data.length,
        category: data.category
    };

    const command = new PutCommand({
        TableName: process.env.COURSES_TABLE,
        Item: item
    });

    try {
        await docClient.send(command);
        return {
            statusCode: 200,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(item)
        };
    } catch (err) {
        return {
            statusCode: 500,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ error: err.message })
        };
    }
};